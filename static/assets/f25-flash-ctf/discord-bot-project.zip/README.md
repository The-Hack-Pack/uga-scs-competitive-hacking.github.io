# discord-bot-project
A simple bot for my Discord server.
